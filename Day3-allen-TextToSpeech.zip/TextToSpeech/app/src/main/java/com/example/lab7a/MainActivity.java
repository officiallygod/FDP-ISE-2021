package com.example.lab7a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // This program converts whatever written by the user to speech
    TextToSpeech t1;
    EditText txtinput;
    Button txttospeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtinput = findViewById(R.id.txt_input);
        txttospeech = findViewById(R.id.btn_txt2spch);

        // This is the way to create a TextToSpeech object and this sets the Language as UK
        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.UK);
                }
            }
        });

        // This speaks out the given words into a speech
        // This method is old and is no longer used so i have used the new method
        txttospeech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tospeak = txtinput.getText().toString();
                Toast.makeText(getBaseContext(),tospeak,Toast.LENGTH_SHORT).show();
                // This method is not functional
//                t1.speak(tospeak, TextToSpeech.QUEUE_FLUSH,null);
                // This is the new alternative and uses another param utteranceId which is an an
                // unique identifier for this request.
                t1.speak(tospeak, TextToSpeech.QUEUE_FLUSH,null, "ID");

            }
        });
    }

    // If the App is stopped the resources are dropped and the memory is cleared
    public void onPause()
    {
        if(t1 != null)
        {
            t1.stop();
            t1.shutdown();
        }
        super.onPause();
    }
}
